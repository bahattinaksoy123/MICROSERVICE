namespace PlatformService.Data
{
    public interface IEntity
    {
        
    }
}